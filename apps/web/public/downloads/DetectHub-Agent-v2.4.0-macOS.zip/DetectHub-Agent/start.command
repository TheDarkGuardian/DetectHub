#!/bin/bash
echo "Initializing DetectHub Digital Forensics Agent v2.4.0..."
open index.html || open http://localhost:1420
